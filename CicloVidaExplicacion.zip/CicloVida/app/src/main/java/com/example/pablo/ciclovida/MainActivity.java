package com.example.pablo.ciclovida;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    //Esto se ejecuta solamente cuando se abre la App
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button sa = (Button) findViewById(R.id.btnSA);

        //El btn nos llevará a la second activity
        sa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                startActivity(intent);
            }
        });


        System.out.println("se ha ejecutado el onCreate");
    }

    //Después de ejecutar la App se ejecuta el onStart
    protected void onStart() {
        super.onStart();
        setContentView(R.layout.activity_main);

        System.out.println("Ha pasado a onStart");
    }

    //Una vez se ha iniciado pasa a onResume que es cuando el usuario puede interactuar con el Activity
    protected void onResume() {
        super.onResume();
        setContentView(R.layout.activity_main);

        System.out.println("Ha pasado a onResume");
    }

    //Cuando la App pasa a estar en segundo plano
    protected void onPause() {
        super.onPause();
        setContentView(R.layout.activity_main);

        System.out.println("Ha pasado a onPause");
    }

    //Cuando la App es eliminada de nuestra memoria RAM
    protected void onStop() {
        super.onStop();
        setContentView(R.layout.activity_main);

        System.out.println("Ha pasado a onStop");
    }

    //Cuando la App es eliminada de nuestra memoria RAM
    protected void onDestroy() {
        super.onDestroy();
        setContentView(R.layout.activity_main);

        System.out.println("Ha pasado a onDestroy");
    }

    /*
    Al pulsar el cuadrado:
        -Pasa al estado onPause
        -Acto seguido pasa a onStop

    Al pulsar cuadrado y eliminar la App:
        -Pasa a onDestroy

    Al pulsar el botón de inicio:
        -Pasa al estado onPause
        -Acto seguido pasa a onStop

    Al pulsar el botón de retroceso:
        -Pasa al estado onPause
        -Acto seguido pasa a onStop

    Cuando pasamos a otra Activity:
        -
     */

}
